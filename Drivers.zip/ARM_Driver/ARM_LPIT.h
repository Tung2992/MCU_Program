#ifndef __LPIT__
#define __LPIT__

void LPIT_Init(void);
void LPIT_Deinit(void);

#endif
