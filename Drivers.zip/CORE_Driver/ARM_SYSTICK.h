#ifndef __SYSTICK__
#define __SYSTICK__

#include "stdint.h"
#include "device_registers.h"

uint32_t SysTick_Config(uint32_t ticks);

#endif
